import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import { supabase } from '../lib/supabase'
import { fmt } from '../lib/precios'

const EST_COLORS = { Pendiente: '#F1EFE8', 'En proceso': '#FAEEDA', Listo: '#EAF3DE', Entregado: '#E6F1FB', Demorado: '#FCEBEB' }
const EST_TC = { Pendiente: '#444441', 'En proceso': '#633806', Listo: '#27500A', Entregado: '#0C447C', Demorado: '#A32D2D' }
const SERV_COLORS = { DTF: '#E1F5EE', Sublimación: '#E6F1FB', Calandrado: '#EEEDFE' }
const SERV_TC = { DTF: '#085041', Sublimación: '#0C447C', Calandrado: '#3C3489' }
const TIMELINE = ['Pedido recibido', 'En producción', 'Listo para entrega', 'Entregado']
const ESTADO_STEP = { Pendiente: 0, 'En proceso': 1, Listo: 2, Entregado: 3, Demorado: 1 }

function fmtF(d) { if (!d) return '—'; const [y, m, dd] = d.slice(0, 10).split('-'); return `${dd}/${m}/${y}` }

export default function MisPedidos() {
  const router = useRouter()
  const [user, setUser] = useState(null)
  const [pedidos, setPedidos] = useState([])
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState(null)
  const [tab, setTab] = useState('todos')
  const [buscar, setBuscar] = useState('')

  useEffect(() => {
    const u = localStorage.getItem('sublicor_user')
    if (!u) { router.push('/'); return }
    const us = JSON.parse(u)
    setUser(us)
    fetchPedidos(us)
  }, [])

  async function fetchPedidos(us) {
    setLoading(true)
    let q = supabase.from('pedidos').select('*').order('fecha_pedido', { ascending: false })
    if (us.rol === 'cliente') q = q.eq('cliente_id', us.id)
    const { data } = await q
    setPedidos(data || [])
    setLoading(false)
  }

  const filtered = pedidos.filter(p => {
    if (tab === 'activos' && !['Pendiente', 'En proceso', 'Listo'].includes(p.estado)) return false
    if (tab === 'entregados' && p.estado !== 'Entregado') return false
    if (buscar && !p.id?.toString().includes(buscar) && !p.cliente_nombre?.toLowerCase().includes(buscar.toLowerCase()) && !p.servicio?.toLowerCase().includes(buscar.toLowerCase())) return false
    return true
  })

  const totalMetros = pedidos.reduce((a, p) => a + (p.metros || 0), 0)
  const totalFacturado = pedidos.filter(p => p.estado === 'Entregado').reduce((a, p) => a + (p.total || 0), 0)

  if (!user) return null

  return (
    <div style={{ minHeight: '100vh', background: '#f3f4f6' }}>
      <nav style={{ background: '#fff', borderBottom: '1px solid #e5e7eb', padding: '12px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 18, fontWeight: 600 }}>Subli<span style={{ color: '#185FA5' }}>cor</span></div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={() => router.push('/tienda')} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer' }}>+ Nuevo pedido</button>
          <button onClick={() => { localStorage.removeItem('sublicor_user'); router.push('/') }} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer', color: '#6b7280' }}>Salir</button>
        </div>
      </nav>

      <div style={{ maxWidth: 720, margin: '0 auto', padding: '20px 16px' }}>
        <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 16 }}>
          {user.rol === 'cliente' ? 'Mis pedidos' : 'Todos los pedidos'}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginBottom: 18 }}>
          {[['Total pedidos', pedidos.length, ''], ['Activos', pedidos.filter(p => ['Pendiente', 'En proceso', 'Listo'].includes(p.estado)).length, '#854F0B'], ['Entregados', pedidos.filter(p => p.estado === 'Entregado').length, '#27500A'], ['Total metros', totalMetros.toFixed(0) + ' m', '']].map(([l, v, c]) => (
            <div key={l} style={{ background: '#f9fafb', borderRadius: 8, padding: '10px 12px' }}>
              <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 3 }}>{l}</div>
              <div style={{ fontSize: 18, fontWeight: 600, color: c || '#111' }}>{v}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', borderBottom: '1px solid #e5e7eb', marginBottom: 14 }}>
          {[['todos', 'Todos'], ['activos', 'Activos'], ['entregados', 'Entregados']].map(([id, l]) => (
            <button key={id} onClick={() => setTab(id)} style={{ padding: '8px 14px', border: 'none', background: 'none', cursor: 'pointer', fontSize: 13, fontWeight: tab === id ? 600 : 400, color: tab === id ? '#185FA5' : '#6b7280', borderBottom: tab === id ? '2px solid #185FA5' : '2px solid transparent', marginBottom: -1 }}>{l}</button>
          ))}
        </div>

        <input value={buscar} onChange={e => setBuscar(e.target.value)} placeholder="Buscar por N°, cliente o servicio..." style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 13, marginBottom: 14 }} />

        {loading ? <div style={{ textAlign: 'center', padding: '3rem', color: '#6b7280' }}>Cargando pedidos...</div>
          : filtered.length === 0 ? <div style={{ textAlign: 'center', padding: '3rem', color: '#9ca3af', border: '1px dashed #d1d5db', borderRadius: 12 }}>No hay pedidos que coincidan</div>
          : filtered.map(p => {
            const step = ESTADO_STEP[p.estado] ?? 0
            const isOpen = open === p.id
            return (
              <div key={p.id} style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, marginBottom: 10, overflow: 'hidden' }}>
                <div onClick={() => setOpen(isOpen ? null : p.id)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', cursor: 'pointer', gap: 8 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 2 }}>#{String(p.id).padStart(4, '0')}{user.rol !== 'cliente' ? ` · ${p.empresa}` : ''}</div>
                    <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginBottom: 4 }}>
                      <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 99, background: SERV_COLORS[p.servicio] || '#f3f4f6', color: SERV_TC[p.servicio] || '#374151' }}>{p.servicio}</span>
                      <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 99, background: EST_COLORS[p.estado] || '#f3f4f6', color: EST_TC[p.estado] || '#374151' }}>{p.estado}</span>
                    </div>
                    <div style={{ fontSize: 12, color: '#6b7280' }}>{p.metros} m · {p.tela}</div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontSize: 12, color: '#9ca3af' }}>{fmtF(p.fecha_pedido)}</div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: '#185FA5' }}>{fmt(p.total || 0)}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 2 }}>{isOpen ? '▲' : '▼'}</div>
                  </div>
                </div>

                {isOpen && (
                  <div style={{ borderTop: '1px solid #e5e7eb', padding: 14 }}>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginBottom: 14 }}>
                      {[['Servicio', p.servicio], ['Metros', p.metros + ' m'], ['Tela', p.tela], ['Fecha pedido', fmtF(p.fecha_pedido)], ['Entrega estimada', fmtF(p.fecha_entrega)], ['Método de pago', p.metodo_pago]].map(([l, v]) => (
                        <div key={l}><div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 2 }}>{l}</div><div style={{ fontSize: 13, fontWeight: 600 }}>{v || '—'}</div></div>
                      ))}
                      {p.notas && <div style={{ gridColumn: '1/-1' }}><div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 2 }}>Notas</div><div style={{ fontSize: 13, color: '#6b7280' }}>{p.notas}</div></div>}
                    </div>

                    <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 10 }}>Seguimiento</div>
                    <div style={{ borderLeft: '2px solid #e5e7eb', marginLeft: 8, paddingLeft: 16 }}>
                      {TIMELINE.map((s, i) => (
                        <div key={s} style={{ position: 'relative', marginBottom: i < TIMELINE.length - 1 ? 10 : 0 }}>
                          <div style={{ position: 'absolute', left: -22, top: 3, width: 10, height: 10, borderRadius: '50%', background: i < step ? '#185FA5' : i === step ? '#EF9F27' : '#f3f4f6', border: i < step ? '2px solid #185FA5' : i === step ? '2px solid #EF9F27' : '2px solid #d1d5db' }} />
                          <div style={{ fontSize: 13, fontWeight: 600, color: i <= step ? '#111' : '#9ca3af' }}>{s}</div>
                          {i < step && <div style={{ fontSize: 11, color: '#9ca3af' }}>Completado</div>}
                          {i === step && <div style={{ fontSize: 11, color: '#854F0B' }}>Estado actual</div>}
                        </div>
                      ))}
                    </div>

                    {p.archivos && <div style={{ marginTop: 12 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Archivos</div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                        {p.archivos.split(',').filter(Boolean).map((f, i) => (
                          <span key={i} style={{ fontSize: 11, background: '#f3f4f6', border: '1px solid #e5e7eb', borderRadius: 99, padding: '3px 10px', color: '#6b7280' }}>📎 {f.trim()}</span>
                        ))}
                      </div>
                    </div>}

                    <div style={{ display: 'flex', gap: 8, marginTop: 14, paddingTop: 12, borderTop: '1px solid #e5e7eb' }}>
                      {p.estado === 'Entregado' && <button onClick={() => router.push('/tienda')} style={{ fontSize: 12, padding: '6px 14px', borderRadius: 8, background: '#185FA5', color: '#fff', border: 'none', cursor: 'pointer' }}>Repetir pedido</button>}
                      <button onClick={() => window.open(`https://wa.me/5493513874533?text=Hola! Consulta sobre pedido %23${String(p.id).padStart(4, '0')}`)} style={{ fontSize: 12, padding: '6px 14px', borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer', color: '#6b7280' }}>Consultar por WhatsApp</button>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
      </div>
    </div>
  )
}
