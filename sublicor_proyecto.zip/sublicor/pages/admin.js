import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import { supabase } from '../lib/supabase'
import { fmt } from '../lib/precios'

function fmtF(d) { if (!d) return '—'; const [y, m, dd] = d.slice(0, 10).split('-'); return `${dd}/${m}/${y}` }
const EST_COLORS = { Pendiente: '#F1EFE8', 'En proceso': '#FAEEDA', Listo: '#EAF3DE', Entregado: '#E6F1FB', Demorado: '#FCEBEB' }
const EST_TC = { Pendiente: '#444441', 'En proceso': '#633806', Listo: '#27500A', Entregado: '#0C447C', Demorado: '#A32D2D' }
const ESTADOS = ['Pendiente', 'En proceso', 'Listo', 'Entregado', 'Demorado']

export default function Admin() {
  const router = useRouter()
  const [user, setUser] = useState(null)
  const [tab, setTab] = useState('pedidos')
  const [pedidos, setPedidos] = useState([])
  const [usuarios, setUsuarios] = useState([])
  const [loading, setLoading] = useState(true)
  const [periodo, setPeriodo] = useState('mes')

  useEffect(() => {
    const u = localStorage.getItem('sublicor_user')
    if (!u) { router.push('/'); return }
    const us = JSON.parse(u)
    if (us.rol !== 'admin') { router.push('/tienda'); return }
    setUser(us)
    fetchAll()
  }, [])

  async function fetchAll() {
    setLoading(true)
    const [{ data: p }, { data: u }] = await Promise.all([
      supabase.from('pedidos').select('*').order('fecha_pedido', { ascending: false }),
      supabase.from('usuarios').select('*').order('fecha_registro', { ascending: false })
    ])
    setPedidos(p || [])
    setUsuarios(u || [])
    setLoading(false)
  }

  async function cambiarEstado(id, estado) {
    await supabase.from('pedidos').update({ estado }).eq('id', id)
    setPedidos(prev => prev.map(p => p.id === id ? { ...p, estado } : p))
  }

  async function toggleUsuario(id, estado) {
    const nuevo = estado === 'activo' ? 'inactivo' : 'activo'
    await supabase.from('usuarios').update({ estado: nuevo }).eq('id', id)
    setUsuarios(prev => prev.map(u => u.id === id ? { ...u, estado: nuevo } : u))
  }

  const now = new Date()
  const filtPedidos = pedidos.filter(p => {
    if (!p.fecha_pedido) return true
    const d = new Date(p.fecha_pedido + 'T12:00:00')
    if (periodo === 'semana') { const mon = new Date(now); mon.setDate(now.getDate() - (now.getDay() || 7) + 1); mon.setHours(0, 0, 0, 0); return d >= mon }
    if (periodo === 'mes') return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
    if (periodo === '3m') { const t = new Date(now); t.setMonth(t.getMonth() - 3); return d >= t }
    return true
  })

  const totalVentas = filtPedidos.filter(p => p.estado === 'Entregado').reduce((a, p) => a + (p.total || 0), 0)
  const totalMetros = filtPedidos.reduce((a, p) => a + (p.metros || 0), 0)
  const clientes = new Set(filtPedidos.map(p => p.cliente_id)).size

  if (!user) return null

  return (
    <div style={{ minHeight: '100vh', background: '#f3f4f6' }}>
      <nav style={{ background: '#fff', borderBottom: '1px solid #e5e7eb', padding: '12px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ fontSize: 18, fontWeight: 600 }}>Subli<span style={{ color: '#185FA5' }}>cor</span></div>
          <span style={{ fontSize: 11, background: '#EEEDFE', color: '#3C3489', borderRadius: 99, padding: '2px 8px', fontWeight: 600 }}>Administrador</span>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button onClick={() => router.push('/produccion')} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer' }}>Panel producción</button>
          <button onClick={() => { localStorage.removeItem('sublicor_user'); router.push('/') }} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer', color: '#6b7280' }}>Salir</button>
        </div>
      </nav>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '20px 16px' }}>
        <div style={{ display: 'flex', borderBottom: '1px solid #e5e7eb', marginBottom: 18 }}>
          {[['pedidos', 'Pedidos'], ['control', 'Panel de control'], ['usuarios', 'Usuarios']].map(([id, l]) => (
            <button key={id} onClick={() => setTab(id)} style={{ padding: '8px 16px', border: 'none', background: 'none', cursor: 'pointer', fontSize: 13, fontWeight: tab === id ? 600 : 400, color: tab === id ? '#185FA5' : '#6b7280', borderBottom: tab === id ? '2px solid #185FA5' : '2px solid transparent', marginBottom: -1 }}>{l}</button>
          ))}
        </div>

        {/* PANEL CONTROL */}
        {tab === 'control' && (
          <div>
            <div style={{ display: 'flex', gap: 6, marginBottom: 16 }}>
              {[['semana', 'Esta semana'], ['mes', 'Este mes'], ['3m', '3 meses'], ['todo', 'Histórico']].map(([id, l]) => (
                <button key={id} onClick={() => setPeriodo(id)} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: periodo === id ? '#185FA5' : 'none', color: periodo === id ? '#fff' : '#6b7280', cursor: 'pointer' }}>{l}</button>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginBottom: 16 }}>
              {[['Facturación', fmt(totalVentas)], ['Metros producidos', totalMetros.toFixed(0) + ' m'], ['Clientes activos', clientes], ['Pedidos totales', filtPedidos.length]].map(([l, v]) => (
                <div key={l} style={{ background: '#f9fafb', borderRadius: 8, padding: '12px' }}>
                  <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 4 }}>{l}</div>
                  <div style={{ fontSize: 20, fontWeight: 600 }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ padding: '11px 16px', borderBottom: '1px solid #e5e7eb', fontSize: 13, fontWeight: 600 }}>Historial de pedidos</div>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                  <thead><tr>{['N°', 'Cliente', 'Servicio', 'Metros', 'Estado', 'Fecha', 'Total'].map(h => (
                    <th key={h} style={{ textAlign: 'left', padding: '7px 10px', borderBottom: '1px solid #e5e7eb', color: '#6b7280', fontWeight: 500, whiteSpace: 'nowrap' }}>{h}</th>
                  ))}</tr></thead>
                  <tbody>{filtPedidos.map((p, i) => (
                    <tr key={p.id} style={{ borderBottom: '1px solid #f3f4f6', background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                      <td style={{ padding: '7px 10px', color: '#9ca3af' }}>#{String(p.id).padStart(4, '0')}</td>
                      <td style={{ padding: '7px 10px', fontWeight: 500 }}>{p.empresa}</td>
                      <td style={{ padding: '7px 10px' }}><span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 99, background: '#E6F1FB', color: '#0C447C', fontWeight: 600 }}>{p.servicio}</span></td>
                      <td style={{ padding: '7px 10px' }}>{p.metros} m</td>
                      <td style={{ padding: '7px 10px' }}><span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 99, background: EST_COLORS[p.estado], color: EST_TC[p.estado], fontWeight: 600 }}>{p.estado}</span></td>
                      <td style={{ padding: '7px 10px', color: '#6b7280' }}>{fmtF(p.fecha_pedido)}</td>
                      <td style={{ padding: '7px 10px', fontWeight: 600, color: '#185FA5' }}>{fmt(p.total || 0)}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* PEDIDOS */}
        {tab === 'pedidos' && (
          <div>
            {loading ? <div style={{ textAlign: 'center', padding: '3rem', color: '#6b7280' }}>Cargando...</div>
              : pedidos.map(p => (
                <div key={p.id} style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, padding: '12px 14px', marginBottom: 10 }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div>
                      <span style={{ fontSize: 11, color: '#9ca3af' }}>#{String(p.id).padStart(4, '0')} · </span>
                      <span style={{ fontSize: 14, fontWeight: 600 }}>{p.empresa || p.cliente_nombre}</span>
                    </div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: '#185FA5' }}>{fmt(p.total || 0)}</div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8, marginBottom: 10, fontSize: 12 }}>
                    {[['Servicio', p.servicio], ['Metros', p.metros + ' m'], ['Entrega', fmtF(p.fecha_entrega)], ['Pago', p.metodo_pago]].map(([l, v]) => (
                      <div key={l}><div style={{ color: '#9ca3af', marginBottom: 1 }}>{l}</div><div style={{ fontWeight: 600 }}>{v}</div></div>
                    ))}
                  </div>
                  <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                    {ESTADOS.map(est => (
                      <button key={est} onClick={() => cambiarEstado(p.id, est)} style={{ fontSize: 11, padding: '3px 10px', borderRadius: 99, border: '1px solid #d1d5db', cursor: 'pointer', background: p.estado === est ? EST_COLORS[est] : 'none', color: p.estado === est ? EST_TC[est] : '#6b7280', fontWeight: p.estado === est ? 600 : 400 }}>{est}</button>
                    ))}
                  </div>
                </div>
              ))}
          </div>
        )}

        {/* USUARIOS */}
        {tab === 'usuarios' && (
          <div>
            <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead><tr>{['Nombre', 'Empresa', 'Usuario', 'WhatsApp', 'Localidad', 'Rol', 'Estado', ''].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '8px 10px', borderBottom: '1px solid #e5e7eb', color: '#6b7280', fontWeight: 500, whiteSpace: 'nowrap' }}>{h}</th>
                ))}</tr></thead>
                <tbody>{usuarios.map((u, i) => (
                  <tr key={u.id} style={{ borderBottom: '1px solid #f3f4f6', background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                    <td style={{ padding: '8px 10px', fontWeight: 500 }}>{u.nombre}</td>
                    <td style={{ padding: '8px 10px', color: '#6b7280' }}>{u.empresa}</td>
                    <td style={{ padding: '8px 10px', color: '#9ca3af' }}>@{u.usuario}</td>
                    <td style={{ padding: '8px 10px', color: '#6b7280' }}>{u.tel}</td>
                    <td style={{ padding: '8px 10px', color: '#6b7280' }}>{u.localidad}</td>
                    <td style={{ padding: '8px 10px' }}><span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 99, background: u.rol === 'admin' ? '#EEEDFE' : u.rol === 'produccion' ? '#E1F5EE' : '#E6F1FB', color: u.rol === 'admin' ? '#3C3489' : u.rol === 'produccion' ? '#085041' : '#0C447C', fontWeight: 600 }}>{u.rol}</span></td>
                    <td style={{ padding: '8px 10px' }}><span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 99, background: u.estado === 'activo' ? '#EAF3DE' : '#FCEBEB', color: u.estado === 'activo' ? '#27500A' : '#A32D2D', fontWeight: 600 }}>{u.estado}</span></td>
                    <td style={{ padding: '8px 10px' }}>
                      {u.id !== user.id && <button onClick={() => toggleUsuario(u.id, u.estado)} style={{ fontSize: 11, padding: '3px 8px', borderRadius: 6, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer', color: '#6b7280' }}>{u.estado === 'activo' ? 'Desactivar' : 'Activar'}</button>}
                    </td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
