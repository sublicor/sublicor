import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import { supabase } from '../lib/supabase'
import { TARIFAS, TELAS_SUBLICOR, TELAS_CLIENTE, PLAZOS, LASER_EXTRA, calcTotal, calcFechaEntrega, fmt } from '../lib/precios'

export default function Tienda() {
  const router = useRouter()
  const [user, setUser] = useState(null)
  const [step, setStep] = useState(1)
  const [selServ, setSelServ] = useState(null)
  const [metros, setMetros] = useState('')
  const [ancho, setAncho] = useState('')
  const [tela, setTela] = useState('')
  const [otraTela, setOtraTela] = useState('')
  const [telaOn, setTelaOn] = useState(false)
  const [selTelaId, setSelTelaId] = useState(null)
  const [laserOn, setLaserOn] = useState(false)
  const [notas, setNotas] = useState('')
  const [metodo, setMetodo] = useState(null)
  const [archivos, setArchivos] = useState([])
  const [loading, setLoading] = useState(false)
  const [ordenNum, setOrdenNum] = useState(null)

  useEffect(() => {
    const u = localStorage.getItem('sublicor_user')
    if (!u) { router.push('/'); return }
    setUser(JSON.parse(u))
  }, [])

  const esCal = selServ === 'Calandrado'
  const m = parseFloat(metros) || 0
  const { subServ, subTela, subLaser, total } = m > 0 && selServ ? calcTotal(selServ, m, telaOn && selTelaId ? selTelaId : null, esCal && laserOn) : { subServ: 0, subTela: 0, subLaser: 0, total: 0 }
  const plazo = esCal && laserOn ? 7 : selServ ? PLAZOS[selServ] : 1
  const fechaEst = selServ ? calcFechaEntrega(selServ, esCal && laserOn) : ''

  function handleFiles(files) {
    const nuevos = Array.from(files).map(f => ({ file: f, nombre: f.name, tamaño: f.size }))
    setArchivos(prev => [...prev, ...nuevos])
  }

  async function confirmarPedido() {
    setLoading(true)
    const { data, error } = await supabase.from('pedidos').insert([{
      cliente_id: user.id,
      cliente_nombre: user.nombre,
      empresa: user.empresa,
      servicio: selServ,
      metros: m,
      ancho: parseFloat(ancho) || null,
      tela: telaOn ? (selTelaId === 'otra' ? otraTela : TELAS_SUBLICOR.find(t => t.id === selTelaId)?.nombre) : tela,
      tela_sublicor: telaOn,
      laser: esCal && laserOn,
      notas,
      metodo_pago: metodo,
      total,
      estado: 'Pendiente',
      fecha_pedido: new Date().toISOString().slice(0, 10),
      fecha_entrega: fechaEst,
      archivos: archivos.map(a => a.nombre).join(', '),
    }]).select().single()
    setLoading(false)
    if (!error && data) { setOrdenNum('#' + String(data.id).padStart(4, '0')); setStep(4) }
    else alert('Hubo un error al registrar el pedido. Intentá de nuevo.')
  }

  if (!user) return null

  const inp = { width: '100%', padding: '8px 10px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 13 }

  const SERVICIOS = [
    { id: 'DTF', icon: '⚡', color: '#E1F5EE', tc: '#085041', plazo: '24 hs', precio: '$9.000/m' },
    { id: 'Sublimación', icon: '🖨', color: '#E6F1FB', tc: '#0C447C', plazo: '24 hs', precio: 'desde $1.900/m' },
    { id: 'Calandrado', icon: '🔄', color: '#EEEDFE', tc: '#3C3489', plazo: '5 días', precio: 'desde $2.450/m' },
  ]

  return (
    <div style={{ minHeight: '100vh', background: '#f3f4f6' }}>
      <nav style={{ background: '#fff', borderBottom: '1px solid #e5e7eb', padding: '12px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 18, fontWeight: 600 }}>Subli<span style={{ color: '#185FA5' }}>cor</span></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 13, color: '#6b7280' }}>{user?.nombre}</span>
          <button onClick={() => router.push('/mis-pedidos')} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer' }}>Mis pedidos</button>
          <button onClick={() => { localStorage.removeItem('sublicor_user'); router.push('/') }} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer', color: '#6b7280' }}>Salir</button>
        </div>
      </nav>

      <div style={{ maxWidth: 680, margin: '0 auto', padding: '20px 16px' }}>

        {/* Steps */}
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 20 }}>
          {['Servicio', 'Medidas', 'Pago', 'Confirmación'].map((s, i) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', flex: i < 3 ? 1 : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 22, height: 22, borderRadius: '50%', background: step > i + 1 ? '#27a05a' : step === i + 1 ? '#185FA5' : '#e5e7eb', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600 }}>{step > i + 1 ? '✓' : i + 1}</div>
                <span style={{ fontSize: 12, color: step === i + 1 ? '#185FA5' : '#9ca3af', fontWeight: step === i + 1 ? 600 : 400 }}>{s}</span>
              </div>
              {i < 3 && <div style={{ flex: 1, height: 1, background: '#e5e7eb', margin: '0 8px' }} />}
            </div>
          ))}
        </div>

        {/* STEP 1 */}
        {step === 1 && (
          <div>
            <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 12 }}>Elegí el servicio que necesitás</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 10, marginBottom: 16 }}>
              {SERVICIOS.map(s => (
                <div key={s.id} onClick={() => setSelServ(s.id)} style={{ background: '#fff', border: selServ === s.id ? '2px solid #185FA5' : '1px solid #e5e7eb', borderRadius: 12, padding: 14, cursor: 'pointer', background: selServ === s.id ? '#E6F1FB' : '#fff' }}>
                  <div style={{ width: 32, height: 32, borderRadius: 8, background: s.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, marginBottom: 8 }}>{s.icon}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>{s.id === 'Sublimación' ? 'Papel de sublimación' : s.id === 'Calandrado' ? 'Impresión + Calandrado' : 'Impresión DTF'}</div>
                  <div style={{ fontSize: 11, color: '#6b7280' }}>Entrega en {s.plazo}</div>
                  <div style={{ fontSize: 11, color: '#185FA5', marginTop: 4, fontWeight: 500 }}>{s.precio} / metro lineal</div>
                </div>
              ))}
            </div>
            <button className="btn-primary" style={{ width: '100%' }} disabled={!selServ} onClick={() => setStep(2)}>Continuar →</button>
          </div>
        )}

        {/* STEP 2 */}
        {step === 2 && (
          <div>
            <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, padding: 16, marginBottom: 14 }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>Medidas del trabajo</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                <div><label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 3 }}>Metros lineales</label>
                  <input type="number" style={inp} value={metros} onChange={e => setMetros(e.target.value)} placeholder="ej: 25" min="0.1" step="0.1" /></div>
                <div><label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 3 }}>Ancho del rollo (cm)</label>
                  <input type="number" style={inp} value={ancho} onChange={e => setAncho(e.target.value)} placeholder="ej: 150" /></div>
              </div>

              {esCal && (
                <div style={{ marginBottom: 10 }}>
                  <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 3 }}>Tela propia</label>
                  <select style={inp} value={tela} onChange={e => setTela(e.target.value)} disabled={telaOn}>
                    <option value="">— Seleccioná —</option>
                    {TELAS_CLIENTE.map(t => <option key={t}>{t}</option>)}
                    <option value="otra">Otra (especificar)</option>
                  </select>
                </div>
              )}

              <div style={{ borderTop: '1px solid #e5e7eb', paddingTop: 12, marginTop: 4 }}>
                <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 6 }}>Archivos de diseño</label>
                <div onClick={() => document.getElementById('fi').click()} style={{ border: '1.5px dashed #d1d5db', borderRadius: 10, padding: '18px', textAlign: 'center', cursor: 'pointer', background: '#f9fafb' }}>
                  <div style={{ fontSize: 13, color: '#6b7280' }}>Arrastrá o hacé clic para subir archivos</div>
                  <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>PDF, AI, PNG, JPG, SVG — sin límite</div>
                </div>
                <input id="fi" type="file" multiple accept=".pdf,.ai,.png,.jpg,.jpeg,.svg" style={{ display: 'none' }} onChange={e => handleFiles(e.target.files)} />
                {archivos.length > 0 && (
                  <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {archivos.map((a, i) => (
                      <div key={i} style={{ fontSize: 11, background: '#E6F1FB', color: '#0C447C', padding: '3px 10px', borderRadius: 99, display: 'flex', alignItems: 'center', gap: 4 }}>
                        {a.nombre}
                        <span onClick={() => setArchivos(prev => prev.filter((_, j) => j !== i))} style={{ cursor: 'pointer', color: '#dc2626' }}>✕</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {esCal && (
              <>
                <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, padding: 14, marginBottom: 12 }}>
                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" checked={telaOn} onChange={e => { setTelaOn(e.target.checked); setSelTelaId(null) }} style={{ marginTop: 2, accentColor: '#185FA5' }} />
                    <div><div style={{ fontSize: 13, fontWeight: 600 }}>Necesito que Sublicor provea la tela</div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>El precio incluye impresión + calandrado + tela.</div></div>
                  </label>
                  {telaOn && (
                    <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #e5e7eb' }}>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                        {TELAS_SUBLICOR.map(t => {
                          const precio = t.esOtra ? 'A cotizar' : m > 0 ? (() => { const p = t.precios.find(p => m <= p.max) || t.precios[t.precios.length - 1]; return fmt(p?.val || 0) + '/m' })() : 'precio por volumen'
                          return (
                            <div key={t.id} onClick={() => setSelTelaId(t.id)} style={{ border: selTelaId === t.id ? '2px solid #534AB7' : '1px solid #e5e7eb', borderRadius: 8, padding: '10px 12px', cursor: 'pointer', background: selTelaId === t.id ? '#EEEDFE' : '#f9fafb' }}>
                              <div style={{ fontSize: 13, fontWeight: 600 }}>{t.nombre}</div>
                              <div style={{ fontSize: 11, color: '#534AB7', marginTop: 2 }}>{precio}</div>
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  )}
                </div>
                <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, padding: 14, marginBottom: 12 }}>
                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" checked={laserOn} onChange={e => setLaserOn(e.target.checked)} style={{ marginTop: 2, accentColor: '#185FA5' }} />
                    <div><div style={{ fontSize: 13, fontWeight: 600 }}>Agregar corte láser</div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>+$600 por metro lineal. Plazo: 7 días hábiles.</div></div>
                  </label>
                </div>
              </>
            )}

            {m > 0 && selServ && (
              <div style={{ background: '#f3f4f6', borderRadius: 12, padding: 14, marginBottom: 14 }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginBottom: 8 }}>
                  {[['Metros', m.toFixed(1) + ' m'], ['Tarifa', esCal && telaOn && selTelaId && !TELAS_SUBLICOR.find(t => t.id === selTelaId)?.esOtra ? 'Con tela' : fmt(TARIFAS[selServ]?.(m)?.tarifa || 0) + '/m'], ['Total', fmt(total)]].map(([l, v]) => (
                    <div key={l} style={{ background: '#fff', borderRadius: 8, padding: 10, textAlign: 'center', border: '1px solid #e5e7eb' }}>
                      <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 3 }}>{l}</div>
                      <div style={{ fontSize: 16, fontWeight: 600, color: l === 'Total' ? '#185FA5' : '#111' }}>{v}</div>
                    </div>
                  ))}
                </div>
                <div style={{ fontSize: 11, color: '#6b7280', textAlign: 'center' }}>
                  Entrega estimada: {new Date(fechaEst + 'T12:00:00').toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' })}
                </div>
              </div>
            )}

            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 4 }}>Notas adicionales (opcional)</label>
              <textarea style={{ ...inp, height: 56, resize: 'vertical' }} value={notas} onChange={e => setNotas(e.target.value)} placeholder="Colores, instrucciones especiales..." />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setStep(1)} style={{ flex: 1, padding: 10, borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer', fontSize: 13 }}>← Volver</button>
              <button className="btn-primary" style={{ flex: 2 }} disabled={!m} onClick={() => setStep(3)}>Ver resumen y pagar →</button>
            </div>
          </div>
        )}

        {/* STEP 3 */}
        {step === 3 && (
          <div>
            <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden', marginBottom: 14 }}>
              <div style={{ padding: '11px 16px', borderBottom: '1px solid #e5e7eb', fontSize: 13, fontWeight: 600 }}>Resumen del pedido</div>
              {[
                ['Cliente', user?.nombre],
                ['Servicio', selServ],
                ['Metros lineales', m.toFixed(1) + ' metros'],
                ['Ancho del rollo', ancho ? ancho + ' cm' : 'No especificado'],
                ['Tela / Material', telaOn ? (TELAS_SUBLICOR.find(t => t.id === selTelaId)?.nombre || '—') : tela || 'No especificada'],
                ['Archivos', archivos.length > 0 ? archivos.length + ' archivo' + (archivos.length > 1 ? 's' : '') : 'Sin archivos'],
                ['Plazo', plazo === 1 ? '24 horas' : plazo + ' días hábiles'],
                ['Entrega estimada', new Date(fechaEst + 'T12:00:00').toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' })],
                ['Total', fmt(total)],
              ].map(([l, v], i, arr) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 16px', fontSize: 13, borderBottom: i < arr.length - 1 ? '1px solid #e5e7eb' : 'none', background: i === arr.length - 1 ? '#f9fafb' : 'transparent', fontWeight: i === arr.length - 1 ? 600 : 400 }}>
                  <span style={{ color: '#6b7280' }}>{l}</span>
                  <span style={{ color: i === arr.length - 1 ? '#185FA5' : '#111' }}>{v}</span>
                </div>
              ))}
            </div>

            <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>Método de pago</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
              {[['mp', 'Mercado Pago', 'Tarjeta, débito, QR o cuenta'], ['transf', 'Transferencia bancaria', 'CVU / alias — confirmación 24 hs']].map(([id, t, sub]) => (
                <div key={id} onClick={() => setMetodo(id)} style={{ border: metodo === id ? '2px solid #185FA5' : '1px solid #e5e7eb', borderRadius: 12, padding: 14, cursor: 'pointer', background: metodo === id ? '#E6F1FB' : '#fff' }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{t}</div>
                  <div style={{ fontSize: 12, color: '#6b7280' }}>{sub}</div>
                </div>
              ))}
            </div>

            {metodo === 'transf' && (
              <div style={{ background: '#E6F1FB', border: '1px solid #B5D4F4', borderRadius: 12, padding: 14, marginBottom: 14, fontSize: 12, color: '#0C447C' }}>
                <div style={{ fontWeight: 600, marginBottom: 8 }}>Datos para la transferencia</div>
                <div>Titular: <strong>Nicolás Salvador Quiñones</strong></div>
                <div>CVU: <strong>0000003100083762210605</strong></div>
                <div>Alias: <strong>sublicorind</strong></div>
                <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid #B5D4F4' }}>
                  Enviá el comprobante a:<br />WhatsApp: 351-3874533 · sublicor_impresiones@yahoo.com
                </div>
              </div>
            )}

            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setStep(2)} style={{ flex: 1, padding: 10, borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer', fontSize: 13 }}>← Volver</button>
              <button className="btn-primary" style={{ flex: 2 }} disabled={!metodo || loading} onClick={confirmarPedido}>
                {loading ? 'Procesando...' : 'Confirmar pedido →'}
              </button>
            </div>
          </div>
        )}

        {/* STEP 4 */}
        {step === 4 && (
          <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 16, padding: 32, textAlign: 'center' }}>
            <div style={{ width: 52, height: 52, borderRadius: '50%', background: '#dcfce7', border: '2px solid #86efac', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', fontSize: 24 }}>✓</div>
            <div style={{ fontSize: 20, fontWeight: 600, color: '#166534', marginBottom: 8 }}>¡Pedido confirmado!</div>
            <div style={{ fontSize: 28, fontWeight: 700, color: '#166534', margin: '10px 0', letterSpacing: 2 }}>{ordenNum}</div>
            <div style={{ fontSize: 13, color: '#6b7280', lineHeight: 1.7, marginBottom: 16 }}>
              Nos comunicamos a la brevedad.<br />
              <strong>WhatsApp:</strong> 351-3874533 · <strong>E-mail:</strong> sublicor_impresiones@yahoo.com
            </div>
            <button className="btn-primary" onClick={() => { setStep(1); setSelServ(null); setMetros(''); setTela(''); setTelaOn(false); setSelTelaId(null); setLaserOn(false); setNotas(''); setMetodo(null); setArchivos([]) }}>Hacer otro pedido</button>
            <button onClick={() => router.push('/mis-pedidos')} style={{ display: 'block', margin: '10px auto 0', fontSize: 13, color: '#185FA5', background: 'none', border: 'none', cursor: 'pointer' }}>Ver mis pedidos →</button>
          </div>
        )}

      </div>
    </div>
  )
}
