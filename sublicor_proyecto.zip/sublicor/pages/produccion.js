import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import { supabase } from '../lib/supabase'
import { fmt } from '../lib/precios'

const ESTADOS = ['Pendiente', 'En proceso', 'Listo', 'Entregado', 'Demorado']
const EST_COLORS = { Pendiente: '#F1EFE8', 'En proceso': '#FAEEDA', Listo: '#EAF3DE', Entregado: '#E6F1FB', Demorado: '#FCEBEB' }
const EST_TC = { Pendiente: '#444441', 'En proceso': '#633806', Listo: '#27500A', Entregado: '#0C447C', Demorado: '#A32D2D' }
function fmtF(d) { if (!d) return '—'; const [y, m, dd] = d.slice(0, 10).split('-'); return `${dd}/${m}/${y}` }

export default function Produccion() {
  const router = useRouter()
  const [user, setUser] = useState(null)
  const [pedidos, setPedidos] = useState([])
  const [loading, setLoading] = useState(true)
  const [periodo, setPeriodo] = useState('hoy')
  const [nota, setNota] = useState({})

  useEffect(() => {
    const u = localStorage.getItem('sublicor_user')
    if (!u) { router.push('/'); return }
    const us = JSON.parse(u)
    if (!['admin', 'produccion'].includes(us.rol)) { router.push('/tienda'); return }
    setUser(us)
    fetchPedidos()
  }, [])

  async function fetchPedidos() {
    setLoading(true)
    const { data } = await supabase.from('pedidos').select('*').neq('estado', 'Entregado').order('fecha_entrega', { ascending: true })
    setPedidos(data || [])
    setLoading(false)
  }

  async function cambiarEstado(id, estado) {
    await supabase.from('pedidos').update({ estado }).eq('id', id)
    setPedidos(prev => prev.map(p => p.id === id ? { ...p, estado } : p))
  }

  async function guardarNota(id) {
    await supabase.from('pedidos').update({ notas_internas: nota[id] }).eq('id', id)
    alert('Nota guardada')
  }

  const today = new Date().toISOString().slice(0, 10)
  const filtered = pedidos.filter(p => {
    if (periodo === 'hoy') return p.fecha_entrega === today
    if (periodo === 'semana') {
      const d = new Date(p.fecha_entrega + 'T12:00:00'), now = new Date()
      const mon = new Date(now); mon.setDate(now.getDate() - (now.getDay() || 7) + 1); mon.setHours(0, 0, 0, 0)
      const sun = new Date(mon); sun.setDate(mon.getDate() + 6)
      return d >= mon && d <= sun
    }
    return true
  })

  if (!user) return null

  return (
    <div style={{ minHeight: '100vh', background: '#f3f4f6' }}>
      <nav style={{ background: '#fff', borderBottom: '1px solid #e5e7eb', padding: '12px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ fontSize: 18, fontWeight: 600 }}>Subli<span style={{ color: '#185FA5' }}>cor</span></div>
          <span style={{ fontSize: 11, background: '#E1F5EE', color: '#085041', borderRadius: 99, padding: '2px 8px', fontWeight: 600 }}>Panel de producción</span>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {['hoy', 'semana', 'todos'].map(p => (
            <button key={p} onClick={() => setPeriodo(p)} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: periodo === p ? '#185FA5' : 'none', color: periodo === p ? '#fff' : '#6b7280', cursor: 'pointer' }}>
              {p === 'hoy' ? 'Hoy' : p === 'semana' ? 'Esta semana' : 'Todos'}
            </button>
          ))}
          <button onClick={() => { localStorage.removeItem('sublicor_user'); router.push('/') }} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: 'none', cursor: 'pointer', color: '#6b7280' }}>Salir</button>
        </div>
      </nav>

      <div style={{ maxWidth: 760, margin: '0 auto', padding: '20px 16px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginBottom: 18 }}>
          {[['Pendientes', pedidos.filter(p => p.estado === 'Pendiente').length, '#854F0B'], ['En proceso', pedidos.filter(p => p.estado === 'En proceso').length, '#185FA5'], ['Listos', pedidos.filter(p => p.estado === 'Listo').length, '#27500A'], ['Vencidos', pedidos.filter(p => p.fecha_entrega < today && p.estado !== 'Entregado').length, '#dc2626']].map(([l, v, c]) => (
            <div key={l} style={{ background: '#f9fafb', borderRadius: 8, padding: '10px 12px' }}>
              <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 3 }}>{l}</div>
              <div style={{ fontSize: 20, fontWeight: 600, color: c }}>{v}</div>
            </div>
          ))}
        </div>

        {loading ? <div style={{ textAlign: 'center', padding: '3rem', color: '#6b7280' }}>Cargando...</div>
          : filtered.length === 0 ? <div style={{ textAlign: 'center', padding: '3rem', color: '#9ca3af', border: '1px dashed #d1d5db', borderRadius: 12 }}>No hay trabajos para este período</div>
          : filtered.map(p => {
            const vencido = p.fecha_entrega < today
            const esHoy = p.fecha_entrega === today
            return (
              <div key={p.id} style={{ background: '#fff', borderRadius: 12, marginBottom: 10, overflow: 'hidden', border: vencido ? '1px solid #fca5a5' : p.prioridad === 'Alta' ? '1px solid #fca5a5' : '1px solid #e5e7eb', borderLeft: vencido || p.prioridad === 'Alta' ? '3px solid #dc2626' : esHoy ? '3px solid #f59e0b' : '1px solid #e5e7eb' }}>
                <div style={{ padding: '12px 14px' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
                    <div>
                      <div style={{ fontSize: 11, color: '#9ca3af' }}>#{String(p.id).padStart(4, '0')}</div>
                      <div style={{ fontSize: 15, fontWeight: 600 }}>{p.empresa || p.cliente_nombre}</div>
                      <div style={{ display: 'flex', gap: 5, marginTop: 4, flexWrap: 'wrap' }}>
                        <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 99, background: '#E6F1FB', color: '#0C447C' }}>{p.servicio}</span>
                        {p.prioridad === 'Alta' && <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 99, background: '#FCEBEB', color: '#A32D2D' }}>Urgente</span>}
                        {p.archivos && <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 99, background: '#f3f4f6', color: '#6b7280' }}>📎 archivo</span>}
                      </div>
                    </div>
                    <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 10px', borderRadius: 99, background: EST_COLORS[p.estado], color: EST_TC[p.estado] }}>{p.estado}</span>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginBottom: 12 }}>
                    {[['Metros', p.metros + ' m'], ['Tela', p.tela], ['Entrega', fmtF(p.fecha_entrega) + (vencido ? ' ⚠️' : esHoy ? ' (hoy)' : '')]].map(([l, v]) => (
                      <div key={l}><div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 1 }}>{l}</div><div style={{ fontSize: 13, fontWeight: 600, color: l === 'Entrega' && vencido ? '#dc2626' : '#111' }}>{v}</div></div>
                    ))}
                  </div>

                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 12 }}>
                    {ESTADOS.map(est => (
                      <button key={est} onClick={() => cambiarEstado(p.id, est)} style={{ fontSize: 12, padding: '4px 12px', borderRadius: 99, border: '1px solid #d1d5db', cursor: 'pointer', background: p.estado === est ? EST_COLORS[est] : 'none', color: p.estado === est ? EST_TC[est] : '#6b7280', fontWeight: p.estado === est ? 600 : 400 }}>{est}</button>
                    ))}
                  </div>

                  <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                    <textarea value={nota[p.id] ?? (p.notas_internas || '')} onChange={e => setNota(prev => ({ ...prev, [p.id]: e.target.value }))} placeholder="Nota interna..." style={{ flex: 1, fontSize: 12, height: 48, padding: '6px 8px', border: '1px solid #e5e7eb', borderRadius: 8, resize: 'none', background: '#f9fafb' }} />
                    <button onClick={() => guardarNota(p.id)} style={{ fontSize: 12, padding: '6px 12px', borderRadius: 8, background: '#185FA5', color: '#fff', border: 'none', cursor: 'pointer', whiteSpace: 'nowrap' }}>Guardar</button>
                  </div>
                </div>
              </div>
            )
          })}
      </div>
    </div>
  )
}
