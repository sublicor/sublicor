import { useState } from 'react'
import { useRouter } from 'next/router'
import { supabase } from '../lib/supabase'

export default function Home() {
  const router = useRouter()
  const [tab, setTab] = useState('login') // 'login' | 'register'
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // LOGIN
  const [loginData, setLoginData] = useState({ usuario: '', pass: '' })

  async function doLogin(e) {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { data, error } = await supabase
      .from('usuarios')
      .select('*')
      .eq('usuario', loginData.usuario)
      .eq('pass', loginData.pass)
      .eq('estado', 'activo')
      .single()
    setLoading(false)
    if (error || !data) { setError('Usuario o contraseña incorrectos'); return }
    localStorage.setItem('sublicor_user', JSON.stringify(data))
    if (data.rol === 'admin') router.push('/admin')
    else if (data.rol === 'produccion') router.push('/produccion')
    else router.push('/tienda')
  }

  // REGISTRO
  const [reg, setReg] = useState({
    nombre: '', dni: '', tel: '', email: '',
    empresa: '', dir: '', localidad: '', provincia: '',
    usuario: '', pass: '', pass2: ''
  })

  async function doRegister(e) {
    e.preventDefault()
    setError('')
    if (reg.pass !== reg.pass2) { setError('Las contraseñas no coinciden'); return }
    if (reg.pass.length < 6) { setError('La contraseña debe tener al menos 6 caracteres'); return }
    setLoading(true)
    const { error } = await supabase.from('usuarios').insert([{
      nombre: reg.nombre, dni: reg.dni, tel: reg.tel,
      email: reg.email, empresa: reg.empresa, dir: reg.dir,
      localidad: reg.localidad, provincia: reg.provincia,
      usuario: reg.usuario, pass: reg.pass,
      rol: 'cliente', estado: 'activo',
      fecha_registro: new Date().toISOString().slice(0, 10)
    }])
    setLoading(false)
    if (error) { setError('El usuario ya existe o hay un error. Intentá con otro nombre de usuario.'); return }
    alert('¡Cuenta creada! Ya podés ingresar.')
    setTab('login')
  }

  const inp = 'width:100%;padding:8px 10px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;margin-top:4px'

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f3f4f6', padding: '2rem' }}>
      <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 16, padding: '2rem', width: 380, maxWidth: '100%' }}>
        <div style={{ fontSize: 24, fontWeight: 600, textAlign: 'center', marginBottom: 4 }}>
          Subli<span style={{ color: '#185FA5' }}>cor</span>
        </div>
        <div style={{ fontSize: 13, color: '#6b7280', textAlign: 'center', marginBottom: 20 }}>
          {tab === 'login' ? 'Ingresá a tu cuenta' : 'Creá tu cuenta'}
        </div>

        <div style={{ display: 'flex', borderBottom: '1px solid #e5e7eb', marginBottom: 20 }}>
          {['login', 'register'].map(t => (
            <button key={t} onClick={() => { setTab(t); setError('') }}
              style={{ flex: 1, padding: '8px', border: 'none', background: 'none', cursor: 'pointer', fontSize: 13,
                fontWeight: tab === t ? 600 : 400, color: tab === t ? '#185FA5' : '#6b7280',
                borderBottom: tab === t ? '2px solid #185FA5' : '2px solid transparent' }}>
              {t === 'login' ? 'Ingresar' : 'Registrarme'}
            </button>
          ))}
        </div>

        {tab === 'login' ? (
          <form onSubmit={doLogin}>
            <label style={{ fontSize: 12, color: '#6b7280' }}>Usuario</label>
            <input style={{ ...inp }} value={loginData.usuario} onChange={e => setLoginData({ ...loginData, usuario: e.target.value })} required placeholder="tu usuario" />
            <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginTop: 10 }}>Contraseña</label>
            <input type="password" style={{ ...inp }} value={loginData.pass} onChange={e => setLoginData({ ...loginData, pass: e.target.value })} required placeholder="••••••" />
            {error && <div style={{ fontSize: 12, color: '#dc2626', marginTop: 8, textAlign: 'center' }}>{error}</div>}
            <button type="submit" className="btn-primary" style={{ width: '100%', marginTop: 16 }} disabled={loading}>
              {loading ? 'Ingresando...' : 'Ingresar'}
            </button>
          </form>
        ) : (
          <form onSubmit={doRegister} style={{ maxHeight: '60vh', overflowY: 'auto', paddingRight: 4 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#9ca3af', marginBottom: 8, marginTop: 4, textTransform: 'uppercase' }}>Datos personales</div>
            {[['nombre','Nombre y apellido','ej: María González'],['dni','DNI','ej: 30123456'],['tel','Teléfono / WhatsApp','ej: 351-1234567'],['email','E-mail','tu@email.com']].map(([k,l,ph])=>(
              <div key={k} style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: '#6b7280' }}>{l} <span style={{ color: '#dc2626' }}>*</span></label>
                <input style={{ ...inp }} value={reg[k]} onChange={e => setReg({ ...reg, [k]: e.target.value })} required placeholder={ph} type={k==='email'?'email':'text'} />
              </div>
            ))}
            <div style={{ fontSize: 11, fontWeight: 600, color: '#9ca3af', marginBottom: 8, marginTop: 4, textTransform: 'uppercase' }}>Empresa / Taller</div>
            <div style={{ marginBottom: 10 }}>
              <label style={{ fontSize: 12, color: '#6b7280' }}>Empresa o taller <span style={{ color: '#dc2626' }}>*</span></label>
              <input style={{ ...inp }} value={reg.empresa} onChange={e => setReg({ ...reg, empresa: e.target.value })} required placeholder="ej: Deportivo Norte" />
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#9ca3af', marginBottom: 8, marginTop: 4, textTransform: 'uppercase' }}>Ubicación</div>
            {[['dir','Dirección','ej: San Martín 1250'],['localidad','Localidad','ej: Córdoba']].map(([k,l,ph])=>(
              <div key={k} style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: '#6b7280' }}>{l} <span style={{ color: '#dc2626' }}>*</span></label>
                <input style={{ ...inp }} value={reg[k]} onChange={e => setReg({ ...reg, [k]: e.target.value })} required placeholder={ph} />
              </div>
            ))}
            <div style={{ marginBottom: 10 }}>
              <label style={{ fontSize: 12, color: '#6b7280' }}>Provincia</label>
              <select style={{ ...inp }} value={reg.provincia} onChange={e => setReg({ ...reg, provincia: e.target.value })}>
                <option value="">— Seleccioná —</option>
                {['Córdoba','Buenos Aires','Santa Fe','Mendoza','Tucumán','Entre Ríos','Salta','Misiones','Chaco','Corrientes','Santiago del Estero','San Juan','Jujuy','Río Negro','Neuquén','Formosa','Chubut','San Luis','Catamarca','La Rioja','La Pampa','Santa Cruz','Tierra del Fuego'].map(p=>(
                  <option key={p}>{p}</option>
                ))}
              </select>
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#9ca3af', marginBottom: 8, marginTop: 4, textTransform: 'uppercase' }}>Acceso</div>
            {[['usuario','Usuario','ej: mgonzalez'],['pass','Contraseña','mínimo 6 caracteres'],['pass2','Repetir contraseña','igual que arriba']].map(([k,l,ph])=>(
              <div key={k} style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: '#6b7280' }}>{l} <span style={{ color: '#dc2626' }}>*</span></label>
                <input type={k.includes('pass')?'password':'text'} style={{ ...inp }} value={reg[k]} onChange={e => setReg({ ...reg, [k]: e.target.value })} required placeholder={ph} />
              </div>
            ))}
            {error && <div style={{ fontSize: 12, color: '#dc2626', marginTop: 4, textAlign: 'center' }}>{error}</div>}
            <button type="submit" className="btn-primary" style={{ width: '100%', marginTop: 12 }} disabled={loading}>
              {loading ? 'Creando cuenta...' : 'Crear cuenta'}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
