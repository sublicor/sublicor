# Sublicor — Plataforma de impresión textil

## Requisitos
- Node.js v18 o superior
- Cuenta en Supabase (base de datos)
- Cuenta en Vercel (hosting)

## Configuración local

1. Cloná o descargá este repositorio
2. Copiá `.env.local.example` y renombralo `.env.local`
3. Completá las claves en `.env.local`
4. Instalá dependencias:
   ```
   npm install
   ```
5. Corré en modo desarrollo:
   ```
   npm run dev
   ```
6. Abrí http://localhost:3000

## Base de datos (Supabase)

Creá estas tablas en Supabase → SQL Editor:

```sql
-- Tabla de usuarios
CREATE TABLE usuarios (
  id SERIAL PRIMARY KEY,
  nombre TEXT NOT NULL,
  dni TEXT,
  tel TEXT,
  email TEXT,
  empresa TEXT,
  dir TEXT,
  localidad TEXT,
  provincia TEXT,
  usuario TEXT UNIQUE NOT NULL,
  pass TEXT NOT NULL,
  rol TEXT DEFAULT 'cliente',
  estado TEXT DEFAULT 'activo',
  fecha_registro DATE DEFAULT CURRENT_DATE
);

-- Tabla de pedidos
CREATE TABLE pedidos (
  id SERIAL PRIMARY KEY,
  cliente_id INTEGER REFERENCES usuarios(id),
  cliente_nombre TEXT,
  empresa TEXT,
  servicio TEXT,
  metros NUMERIC,
  ancho NUMERIC,
  tela TEXT,
  tela_sublicor BOOLEAN DEFAULT FALSE,
  laser BOOLEAN DEFAULT FALSE,
  notas TEXT,
  notas_internas TEXT,
  metodo_pago TEXT,
  total NUMERIC,
  estado TEXT DEFAULT 'Pendiente',
  fecha_pedido DATE DEFAULT CURRENT_DATE,
  fecha_entrega DATE,
  archivos TEXT
);

-- Usuario administrador inicial
INSERT INTO usuarios (nombre, dni, tel, email, empresa, dir, localidad, provincia, usuario, pass, rol, estado)
VALUES ('Nicolas Quinones', '12345678', '351-3874533', 'sublicor_impresiones@yahoo.com', 'Sublicor', 'Cordoba', 'Cordoba', 'Cordoba', 'nicolas', 'admin123', 'admin', 'activo');
```

## Publicar en Vercel

1. Subí el código a GitHub
2. Conectá el repositorio en vercel.com
3. Agregá las variables de entorno en Vercel → Settings → Environment Variables
4. Hacé Deploy

## Variables de entorno necesarias en Vercel

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `CLOUDFLARE_R2_ACCESS_KEY`
- `CLOUDFLARE_R2_SECRET_KEY`
- `CLOUDFLARE_R2_BUCKET`
- `CLOUDFLARE_R2_ENDPOINT`
- `MP_ACCESS_TOKEN`
